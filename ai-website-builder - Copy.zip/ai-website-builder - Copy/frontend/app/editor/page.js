"use client"

import { useState, useEffect } from "react"

import SectionLibrary from "../components/SectionLibrary"
import BuilderCanvas from "../components/BuilderCanvas"
import StyleEditor from "../components/StyleEditor"
import MediaLibrary from "../components/MediaLibrary"
import PageManager from "../components/PageManager"
import { useSearchParams } from "next/navigation"

export default function Editor(){

const [editor,setEditor] = useState(null)
const [prompt,setPrompt] = useState("")
const [pages,setPages] = useState({})
const searchParams = useSearchParams()
const siteId = searchParams.get("id")
// AI website generate
const generateSite = ()=>{

fetch("http://127.0.0.1:8000/generate-site",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

prompt:prompt

})

})
.then(res=>res.json())
.then(data=>{

editor.setComponents(data.html)

})


}
useEffect(()=>{

if(!siteId) return

fetch("http://127.0.0.1:8000/site/"+siteId)
.then(res=>res.json())
.then(data=>{

if(editor){

editor.setComponents(data.html)

}

})

},[editor])
const generateSections = ()=>{

fetch("http://127.0.0.1:8000/generate-sections",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

prompt:prompt

})

})
.then(res=>res.json())
.then(()=>{

alert("AI Sections Created")

})

}
// save website
const saveSite = ()=>{

if(!editor) return

const html = editor.getHtml()
const css = editor.getCss()

fetch("http://127.0.0.1:8000/save-site",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

name:"my-site",
html:html,
css:css

})

})
.then(res=>res.json())
.then(()=>{

alert("Website Saved")

})

}
const loadPage = (page)=>{

if(editor){

editor.setComponents(pages[page])

}

}
// publish website
const publishSite = ()=>{

if(!editor) return

const html = editor.getHtml()
const css = editor.getCss()

fetch("http://127.0.0.1:8000/publish",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

name:"my-site",
html:html,
css:css

})

})
.then(res=>res.json())
.then(data=>{

alert("Website Published: "+data.url)

})

}

return(

<div style={{display:"flex",height:"100vh"}}>

{/* LEFT PANEL */}


<PageManager pages={pages} loadPage={loadPage}/>
<SectionLibrary editor={editor}/>
{/* CENTER */}

<div style={{flex:1,display:"flex",flexDirection:"column"}}>

{/* TOP BAR */}

<div style={{
padding:"10px",
borderBottom:"1px solid #ddd",
display:"flex",
justifyContent:"space-between"
}}>

<h3>AI Website Builder</h3>

<div>

<input
type="text"
placeholder="Describe your website..."
value={prompt}
onChange={(e)=>setPrompt(e.target.value)}
style={{
padding:"6px",
marginRight:"10px",
width:"250px"
}}
/>

<button
onClick={generateSite}
style={{
marginRight:"10px",
padding:"8px 15px",
background:"green",
color:"white",
border:"none"
}}
>
Generate
</button>

<button
onClick={saveSite}
style={{
marginRight:"10px",
padding:"8px 15px",
background:"black",
color:"white",
border:"none"
}}
>
Save
</button>

<button
onClick={()=>editor?.setDevice("Desktop")}
style={{marginRight:"10px"}}
>
Desktop
</button>

<button
onClick={()=>editor?.setDevice("Tablet")}
style={{marginRight:"10px"}}
>
Tablet
</button>

<button
onClick={()=>editor?.setDevice("Mobile")}
style={{marginRight:"10px"}}
>
Mobile
</button>

<button onClick={publishSite}>
Publish
</button>
<button
onClick={generateSections}
style={{
marginRight:"10px",
padding:"8px 15px",
background:"purple",
color:"white",
border:"none"
}}
>

Generate Sections

</button>

</div>

</div>

{/* BUILDER */}

<div style={{flex:1}}>

<BuilderCanvas setEditor={setEditor}/>

</div>

</div>

{/* RIGHT PANEL */}

<StyleEditor editor={editor}/>
<MediaLibrary editor={editor}/>

</div>

)

}