from supabase import create_client

SUPABASE_URL = "https://fswpuepiuvtoolnyygkg.supabase.co"
SUPABASE_KEY = "sb_publishable_hI4lcsz32oqeUl_h-gXmbQ_rpzYD49N"

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)


def create_tables():
    
    queries = [

    """
    create table if not exists users (
        id uuid primary key default uuid_generate_v4(),
        name text,
        email text unique,
        password text,
        plan text default 'free',
        created_at timestamp default now()
    );
    """,

    """
    create table if not exists websites (
        id uuid primary key default uuid_generate_v4(),
        user_id uuid,
        name text,
        domain text,
        template_id uuid,
        status text default 'draft',
        created_at timestamp default now()
    );
    """,

    """
    create table if not exists templates (
        id uuid primary key default uuid_generate_v4(),
        name text,
        industry text,
        style text,
        preview_image text,
        tags text[],
        created_at timestamp default now()
    );
    """,

    """
    create table if not exists sections (
        id uuid primary key default uuid_generate_v4(),
        name text,
        category text,
        industry text,
        style text,
        html_code text,
        css_code text,
        js_code text,
        preview_image text,
        tags text[],
        created_at timestamp default now()
    );
    """,

    """
    create table if not exists components (
        id uuid primary key default uuid_generate_v4(),
        section_id uuid,
        name text,
        html text,
        css text,
        js text,
        tags text[]
    );
    """,

    """
    create table if not exists themes (
        id uuid primary key default uuid_generate_v4(),
        name text,
        font text,
        color_palette jsonb,
        spacing text,
        border_radius text
    );
    """

    ]

    for q in queries:
        supabase.rpc("sql", {"query": q}).execute()

    print("✅ Tables created successfully")


if __name__ == "__main__":
    create_tables()