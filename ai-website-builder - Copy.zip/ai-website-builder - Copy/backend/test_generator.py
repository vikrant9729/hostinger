from app.services.website_generator import generate_website


prompt = "restaurant website with gallery"

html = generate_website(prompt)

with open("generated_site.html", "w", encoding="utf-8") as f:
    f.write(html)

print("Website generated")