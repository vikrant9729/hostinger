from app.core.database import supabase

res = supabase.table("sections").select("*").execute()

print(res.data)
print("TOTAL:", len(res.data))