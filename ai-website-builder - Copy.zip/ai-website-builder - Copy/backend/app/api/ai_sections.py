from fastapi import APIRouter
from app.services.ai_section_generator import generate_sections

router = APIRouter()


@router.post("/generate-sections")

def generate(data: dict):

    prompt = data["prompt"]

    result = generate_sections(prompt)

    return {

        "sections": result

    }