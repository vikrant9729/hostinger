from fastapi import APIRouter
from app.services.ai_image_engine import generate_ai_image

router = APIRouter()


@router.post("/generate-image")

def generate(data: dict):

    prompt = data["prompt"]

    img = generate_ai_image(prompt)

    if img is None:

        return {"error": "image generation failed"}

    return {"url": img}