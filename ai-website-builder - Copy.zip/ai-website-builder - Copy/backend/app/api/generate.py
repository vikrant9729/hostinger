from fastapi import APIRouter
from app.services.design_engine import generate_design

router = APIRouter()


@router.post("/generate")

def generate(data: dict):

    prompt = data["prompt"]

    html = generate_design(prompt)

    return {

        "html": html

    }