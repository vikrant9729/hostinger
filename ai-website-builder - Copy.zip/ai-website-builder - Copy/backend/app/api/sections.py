from fastapi import APIRouter
from app.core.database import supabase

router = APIRouter()


@router.get("/sections")
def get_sections():

    res = supabase.table("sections").select("*").limit(100).execute()

    return res.data


@router.get("/sections/{category}")
def get_sections_by_category(category: str):

    res = supabase.table("sections")\
        .select("*")\
        .eq("category", category)\
        .limit(50)\
        .execute()

    return res.data