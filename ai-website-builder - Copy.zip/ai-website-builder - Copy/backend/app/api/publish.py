from fastapi import APIRouter
import os

router = APIRouter()

SITE_DIR = "sites"

os.makedirs(SITE_DIR, exist_ok=True)


@router.post("/publish")

def publish_site(data: dict):

    name = data["name"]

    html = data["html"]

    css = data["css"]

    site_folder = os.path.join(SITE_DIR, name)

    os.makedirs(site_folder, exist_ok=True)

    full_html = f"""
<html>
<head>
<style>
{css}
</style>
</head>

<body>

{html}

</body>
</html>
"""

    file_path = os.path.join(site_folder,"index.html")

    with open(file_path,"w",encoding="utf-8") as f:

        f.write(full_html)

    return {

        "url":f"http://{name}.localhost:8000"

    }