from fastapi import APIRouter
from app.core.database import supabase

router = APIRouter()


@router.get("/websites/{user_id}")

def get_websites(user_id: str):

    res = supabase.table("websites")\
        .select("*")\
        .eq("user_id",user_id)\
        .execute()

    return res.data


@router.delete("/delete-website/{site_id}")

def delete_website(site_id: str):

    supabase.table("websites")\
        .delete()\
        .eq("id",site_id)\
        .execute()

    return {"status":"deleted"}