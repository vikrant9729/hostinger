from fastapi import APIRouter
from app.core.database import supabase
import uuid

router = APIRouter()


@router.post("/signup")
def signup(data: dict):

    user = {

        "id": str(uuid.uuid4()),

        "email": data["email"],

        "password": data["password"]

    }

    supabase.table("users").insert(user).execute()

    return {"status":"user created"}


@router.post("/login")
def login(data: dict):

    res = supabase.table("users")\
        .select("*")\
        .eq("email",data["email"])\
        .eq("password",data["password"])\
        .execute()

    if res.data:

        return {"user":res.data[0]}

    return {"error":"invalid login"}