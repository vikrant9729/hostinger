from fastapi import APIRouter
from app.core.database import supabase

router = APIRouter()

@router.get("/sites")
def get_sites():

    res = supabase.table("websites").select("*").execute()

    return res.data