from fastapi import APIRouter
from app.services.website_renderer import render_website

router = APIRouter()


@router.post("/generate-site")

def generate(data: dict):

    prompt = data["prompt"]

    html = render_website(prompt)

    return {

        "html": html

    }