from app.services.ai_generator import generate_ai_website


def generate_multi_page(prompt):

    pages = {

        "home": f"{prompt} homepage landing",

        "about": f"about page for {prompt}",

        "services": f"services page for {prompt}",

        "contact": f"contact page with form for {prompt}"

    }

    result = {}

    for page, page_prompt in pages.items():

        html = generate_ai_website(page_prompt)

        result[page] = html

    return result