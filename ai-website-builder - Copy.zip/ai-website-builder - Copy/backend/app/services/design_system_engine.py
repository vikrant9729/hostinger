import random


def generate_design_system(industry):

    systems = {

        "startup":{
            "font":"Inter",
            "primary":"#4F46E5",
            "secondary":"#06B6D4",
            "background":"#F9FAFB",
            "button_radius":"8px"
        },

        "restaurant":{
            "font":"Playfair Display",
            "primary":"#B91C1C",
            "secondary":"#F59E0B",
            "background":"#FFF7ED",
            "button_radius":"6px"
        },

        "portfolio":{
            "font":"Poppins",
            "primary":"#111827",
            "secondary":"#6366F1",
            "background":"#FFFFFF",
            "button_radius":"10px"
        },

        "general":{
            "font":"Arial",
            "primary":"#333",
            "secondary":"#666",
            "background":"#ffffff",
            "button_radius":"6px"
        }

    }

    return systems.get(industry, systems["general"])