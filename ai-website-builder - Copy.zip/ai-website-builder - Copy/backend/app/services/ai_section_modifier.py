import requests
import json


def modify_section(html):

    prompt = f"""
Improve this HTML section to make it modern and responsive.

Return only HTML.

{html}
"""

    try:

        response = requests.post(

            "https://openrouter.ai/api/v1/chat/completions",

            headers={
                "Authorization": "Bearer YOUR_OPENROUTER_KEY",
                "Content-Type": "application/json"
            },

            json={
                "model": "mistralai/mistral-7b-instruct",
                "messages": [
                    {"role":"user","content":prompt}
                ]
            }

        )

        data = response.json()

        return data["choices"][0]["message"]["content"]

    except:

        return html