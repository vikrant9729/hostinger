import random
from app.core.database import supabase


def get_font(industry=None):

    res = supabase.table("fonts").select("*").execute()

    if not res.data:
        return {
            "name": "Arial"
        }

    font = random.choice(res.data)

    return {
        "name": font.get("name", "Arial")
    }