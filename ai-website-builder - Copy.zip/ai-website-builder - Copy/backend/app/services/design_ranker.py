import random

def score_section(section):

    score = 0

    html = section["html_code"]

    # HTML length
    score += min(len(html) / 500, 10)

    # modern class names
    if "container" in html:
        score += 2

    if "row" in html:
        score += 2

    if "col" in html:
        score += 2

    # image presence
    if "<img" in html:
        score += 2

    return score


def pick_best_section(sections):

    scored = []

    for s in sections:

        score = score_section(s)

        scored.append((score, s))

    scored.sort(key=lambda x: x[0], reverse=True)

    best = scored[:5]

    return random.choice(best)[1]