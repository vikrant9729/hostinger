from app.services.template_generator import generate_template, save_template


def generate_templates():

    industries = [

        "startup",
        "restaurant",
        "portfolio",
        "agency"

    ]

    for industry in industries:

        html = generate_template(industry)

        save_template(html)

    print("AI templates generated")