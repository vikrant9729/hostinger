import random
from app.core.database import supabase


def get_section(category):

    res = supabase.table("sections")\
        .select("*")\
        .eq("category", category)\
        .execute()

    if not res.data:
        return ""

    section = random.choice(res.data)

    return section["html_code"]


def generate_website(prompt):

    layout = [

        "navbar",
        "hero",
        "features",
        "gallery",
        "testimonials",
        "contact",
        "footer"

    ]

    html = ""

    for section in layout:

        html += get_section(section)

    return html