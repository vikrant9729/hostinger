import random
from app.services.prompt_analyzer import analyze_prompt
from app.services.template_service import get_template_by_industry
from app.services.section_selector import get_sections


def generate_website(prompt):

    industry = analyze_prompt(prompt)

    templates = get_template_by_industry(industry)

    template = random.choice(templates)

    layout = template["layout"]

    sections = []

    for cat in layout:

        sec = get_sections(cat)

        if sec:

            sections.append(sec[0]["html_code"])

    website_html = "\n".join(sections)

    return website_html