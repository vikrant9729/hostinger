from app.core.database import supabase


def save_template(name, layout):

    data = {

        "name": name,

        "layout": layout,

        "industry": "general",

        "style": "modern"

    }

    supabase.table("templates").insert(data).execute()


def get_templates():

    res = supabase.table("templates").select("*").execute()

    return res.data

from app.core.database import supabase

def get_template_by_industry(industry):

    res = supabase.table("templates")\
        .select("*")\
        .eq("industry", industry)\
        .execute()

    if res.data:
        return res.data

    return supabase.table("templates").select("*").execute().data