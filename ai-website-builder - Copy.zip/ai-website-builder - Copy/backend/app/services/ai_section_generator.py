from app.services.ai_generator import generate_ai_website
from app.core.database import supabase


def generate_sections(prompt):

    section_types = [

        "hero section",

        "features section",

        "pricing section",

        "testimonial section",

        "contact section",

        "footer section"

    ]

    created = []

    for section in section_types:

        full_prompt = f"{section} for {prompt}"

        html = generate_ai_website(full_prompt)

        data = {

            "name": section,

            "category": section.split()[0],

            "industry": "general",

            "style": "modern",

            "html_code": html,

            "css_code": "",

            "js_code": "",

            "preview_image": "",

            "tags": [section]

        }

        supabase.table("sections").insert(data).execute()

        created.append(section)

    return created