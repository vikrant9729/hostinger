from app.services.layout_engine_ai import generate_layout
from app.services.color_engine import generate_colors


def generate_design(prompt):

    html = generate_layout(prompt)

    colors = generate_colors()

    styled_html = f"""

<div style="background:{colors['background']}">

{html}

</div>

"""

    return styled_html