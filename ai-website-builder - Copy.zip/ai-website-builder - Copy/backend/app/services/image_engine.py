import random
from app.core.database import supabase


def get_images(category):

    res = supabase.table("images")\
        .select("*")\
        .eq("category", category)\
        .execute()

    if not res.data:
        return []

    return random.sample(res.data, min(5, len(res.data)))