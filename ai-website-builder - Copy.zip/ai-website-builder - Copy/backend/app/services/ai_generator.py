import os
import requests
from dotenv import load_dotenv

load_dotenv()

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
OLLAMA_URL = os.getenv("OLLAMA_URL")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL")


# -------- OPENROUTER -------- #

def generate_openrouter(prompt):

    url = "https://openrouter.ai/api/v1/chat/completions"

    headers = {

        "Authorization": f"Bearer {OPENROUTER_API_KEY}",

        "Content-Type": "application/json"

    }

    data = {

        "model": "meta-llama/llama-3-8b-instruct",

        "messages": [

            {

                "role": "user",

                "content": f"""
Create HTML landing page sections for:

{prompt}

Use clean HTML and Tailwind classes.
Return only HTML.
"""

            }

        ]

    }

    res = requests.post(url, headers=headers, json=data)

    result = res.json()

    return result["choices"][0]["message"]["content"]


# -------- OLLAMA -------- #

def generate_ollama(prompt):

    url = f"{OLLAMA_URL}/api/generate"

    data = {

        "model": OLLAMA_MODEL,

        "prompt": f"""
Generate HTML landing page for:

{prompt}

Return only HTML code.
""",

        "stream": False

    }

    res = requests.post(url, json=data)

    return res.json()["response"]


# -------- AUTO SELECT -------- #

def generate_ai_website(prompt):

    try:

        return generate_openrouter(prompt)

    except:

        print("OpenRouter failed → switching to Ollama")

        return generate_ollama(prompt)