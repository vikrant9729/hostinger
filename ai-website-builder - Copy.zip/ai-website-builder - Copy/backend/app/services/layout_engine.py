def get_layout(industry):

    layouts = {

        "restaurant":[
            "navbar",
            "hero",
            "features",
            "gallery",
            "testimonials",
            "contact",
            "footer"
        ],

        "startup":[
            "navbar",
            "hero",
            "features",
            "pricing",
            "testimonials",
            "faq",
            "contact",
            "footer"
        ],

        "portfolio":[
            "navbar",
            "hero",
            "gallery",
            "about",
            "contact",
            "footer"
        ],

        "ecommerce":[
            "navbar",
            "hero",
            "features",
            "gallery",
            "testimonials",
            "contact",
            "footer"
        ],

        "general":[
            "navbar",
            "hero",
            "features",
            "gallery",
            "contact",
            "footer"
        ]

    }

    return layouts.get(industry, layouts["general"])