from app.core.database import supabase
import hashlib


def hash_html(html):
    return hashlib.md5(html.encode()).hexdigest()


def remove_duplicates():

    res = supabase.table("sections").select("*").execute()

    sections = res.data

    print("Total sections:", len(sections))

    seen = {}

    for sec in sections:

        html = sec["html_code"]

        h = hash_html(html)

        if h in seen:

            print("Duplicate found:", sec["id"])

            supabase.table("sections")\
                .delete()\
                .eq("id", sec["id"])\
                .execute()

        else:

            seen[h] = sec["id"]

    print("Duplicate cleaning finished")


if __name__ == "__main__":

    remove_duplicates()