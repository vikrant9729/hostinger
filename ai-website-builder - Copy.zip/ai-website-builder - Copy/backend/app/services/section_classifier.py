from app.core.database import supabase


def detect_category(html):

    html = html.lower()

    if "<nav" in html:
        return "navbar"

    if "hero" in html or "banner" in html:
        return "hero"

    if "pricing" in html or "price" in html:
        return "pricing"

    if "testimonial" in html:
        return "testimonials"

    if "gallery" in html or "portfolio" in html:
        return "gallery"

    if "contact" in html:
        return "contact"

    if "<footer" in html:
        return "footer"

    return "section"