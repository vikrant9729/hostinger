import requests
import uuid
import os

IMAGE_DIR = "uploads"
os.makedirs(IMAGE_DIR, exist_ok=True)


def save_image(content):

    file_name = str(uuid.uuid4()) + ".png"
    file_path = os.path.join(IMAGE_DIR, file_name)

    with open(file_path, "wb") as f:
        f.write(content)

    return f"/uploads/{file_name}"


# -------- POLLINATIONS -------- #

def pollinations_image(prompt):

    prompt = prompt.replace(" ", "%20")

    url = f"https://image.pollinations.ai/prompt/{prompt}?width=1024&height=768"

    res = requests.get(url)

    if res.status_code == 200:

        return save_image(res.content)

    return None


# -------- OPENROUTER -------- #

def openrouter_image(prompt):

    try:

        url = "https://openrouter.ai/api/v1/images/generations"

        headers = {

            "Authorization": "Bearer YOUR_OPENROUTER_API_KEY",
            "Content-Type": "application/json"

        }

        data = {

            "model": "stabilityai/sdxl",

            "prompt": prompt,

            "size": "1024x1024"

        }

        res = requests.post(url, json=data, headers=headers)

        img_url = res.json()["data"][0]["url"]

        img = requests.get(img_url).content

        return save_image(img)

    except:

        return None


# -------- OLLAMA SD -------- #

def ollama_image(prompt):

    try:

        url = "http://localhost:11434/api/generate"

        data = {

            "model": "sd",

            "prompt": prompt,

            "stream": False

        }

        res = requests.post(url, json=data)

        img_data = res.json()["response"]

        img = requests.get(img_data).content

        return save_image(img)

    except:

        return None


# -------- MASTER GENERATOR -------- #

def generate_ai_image(prompt):

    img = openrouter_image(prompt)

    if img:
        return img

    img = pollinations_image(prompt)

    if img:
        return img

    img = ollama_image(prompt)

    return img