import random
from app.core.database import supabase
import uuid
def save_template(html):

    supabase.table("templates").insert({

        "id":str(uuid.uuid4()),
        "name":"ai_generated_template",
        "industry":"general",
        "style":"modern",
        "layout":"auto",
        "preview":"",
        "html_code":html,
        "css_code":"",
        "js_code":"",
        "tags":["ai","generated"]

    }).execute()

def generate_template(industry):

    layout = [

        "navbar",
        "hero",
        "features",
        "gallery",
        "testimonials",
        "contact",
        "footer"

    ]

    template_html = ""

    for category in layout:

        res = supabase.table("sections")\
            .select("*")\
            .eq("category", category)\
            .execute()

        if not res.data:
            continue

        section = random.choice(res.data)

        template_html += section["html_code"]

    return template_html