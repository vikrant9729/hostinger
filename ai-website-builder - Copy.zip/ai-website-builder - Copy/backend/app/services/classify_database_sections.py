from app.core.database import supabase
from app.services.section_classifier import classify_section


def classify_all_sections():

    response = supabase.table("sections").select("*").execute()

    sections = response.data

    for sec in sections:

        html = sec["html_code"]

        category = classify_section(html)

        supabase.table("sections").update({
            "category": category
        }).eq("id", sec["id"]).execute()

        print("Classified:", category)


if __name__ == "__main__":
    classify_all_sections()